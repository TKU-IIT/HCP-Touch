<?php
//$fp=fopen('result.txt','w');
//fwrite($fp,"hi");
//fclose($fp);
    // Connect to mysqli
    include("dbconnect.php");
$CardNumber = mysqli_real_escape_string($conn,$_GET['CardNumber']);
$CardBalance = mysqli_real_escape_string($conn,$_GET['CardBalance']);
$CardType = mysqli_real_escape_string($conn,$_GET['CardType']);
    // Prepare the SQL statement
    $query =  "INSERT INTO CardInfo (id, CardNumber, CardBalance, CardType) VALUES (0, '$CardNumber', '$CardBalance', '$CardType')";    
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    // Go to the review_data.php (optional)
    //header("Location: review_data.php");
	
if ($conn->query($query) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}

$conn->close();
?>
