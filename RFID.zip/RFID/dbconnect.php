
<?php

$servername = "localhost";
$username = "root";
$password = "jefflin123";

$dbname = "choihong";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
?>
